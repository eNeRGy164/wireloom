cmake_minimum_required(VERSION 3.20)
project(WireloomHelloWorldCpp LANGUAGES CXX)

if(NOT DEFINED ENV{NDDSHOME})
    message(FATAL_ERROR "Set NDDSHOME to your RTI Connext DDS 7.7.0 installation.")
endif()
list(APPEND CMAKE_MODULE_PATH "$ENV{NDDSHOME}/resource/cmake")
find_package(RTIConnextDDS 7.7.0 EXACT REQUIRED)
find_package(WireloomCpp CONFIG REQUIRED)

add_executable(wireloom_hello_world main.cpp)
set_target_properties(wireloom_hello_world PROPERTIES
    CXX_STANDARD 11
    CXX_STANDARD_REQUIRED YES
    CXX_EXTENSIONS NO
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
target_link_libraries(wireloom_hello_world PRIVATE RTIConnextDDS::cpp2_api)
wireloom_add_idl(wireloom_hello_world
    IDL "${CMAKE_CURRENT_SOURCE_DIR}/hello_world.idl")
