#include "hello_world.hpp"
#include <dds/dds.hpp>

#include <chrono>
#include <csignal>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>

namespace {
using Clock = std::chrono::steady_clock;
const int sample_count = 10;
volatile std::sig_atomic_t stop_requested = 0;

void stop(int)
{
    stop_requested = 1;
}

void publish(const dds::domain::DomainParticipant& participant,
             const dds::topic::Topic<HelloWorld>& topic)
{
    const dds::pub::Publisher publisher(participant);
    auto qos = publisher.default_datawriter_qos();
    qos << dds::core::policy::Reliability::Reliable()
        << dds::core::policy::History::KeepAll();
    dds::pub::DataWriter<HelloWorld> writer(publisher, topic, qos);

    std::cout << "Waiting for a matching subscriber..." << std::endl;
    const auto deadline = Clock::now() + std::chrono::seconds(30);
    while (!stop_requested
           && writer.publication_matched_status().current_count() == 0) {
        if (Clock::now() >= deadline) {
            throw std::runtime_error("No subscriber matched within 30 seconds.");
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    HelloWorld sample;
    for (int number = 1; number <= sample_count && !stop_requested; ++number) {
        sample.msg = "Hello world! " + std::to_string(number);
        writer.write(sample);
        std::cout << "Sent: " << sample.msg << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    if (!stop_requested) {
        writer.wait_for_acknowledgments(dds::core::Duration(10));
        std::cout << "Acknowledged " << sample_count << " samples." << std::endl;
    }
}

void subscribe(const dds::domain::DomainParticipant& participant,
               const dds::topic::Topic<HelloWorld>& topic)
{
    const dds::sub::Subscriber subscriber(participant);
    auto qos = subscriber.default_datareader_qos();
    qos << dds::core::policy::Reliability::Reliable()
        << dds::core::policy::History::KeepAll();
    dds::sub::DataReader<HelloWorld> reader(subscriber, topic, qos);

    int received = 0;
    auto deadline = Clock::now() + std::chrono::seconds(30);
    dds::core::cond::StatusCondition available(reader);
    available.enabled_statuses(dds::core::status::StatusMask::data_available());
    available.extensions().handler([&reader, &received, &deadline]() {
        const auto samples = reader.take();
        for (const auto& sample : samples) {
            if (sample.info().valid()) {
                std::cout << "Received: " << sample.data().msg << std::endl;
                ++received;
                deadline = Clock::now() + std::chrono::seconds(30);
            }
        }
    });
    dds::core::cond::WaitSet waitset;
    waitset += available;

    std::cout << "Waiting for samples..." << std::endl;
    while (received < sample_count && !stop_requested) {
        if (Clock::now() >= deadline) {
            throw std::runtime_error("No sample received within 30 seconds.");
        }
        waitset.dispatch(dds::core::Duration::from_millisecs(250));
    }
    if (!stop_requested) {
        std::cout << "Received " << received << " samples." << std::endl;
    }
}
}

int main(int argc, char** argv)
{
    if (argc != 2 || (std::string(argv[1]) != "--pub"
                      && std::string(argv[1]) != "--sub")) {
        std::cerr << "Usage: wireloom_hello_world --pub | --sub\n";
        return 2;
    }
    std::signal(SIGINT, stop);
    try {
        const dds::domain::DomainParticipant participant(0);
        const dds::topic::Topic<HelloWorld> topic(participant, "HelloWorld Topic");
        if (std::string(argv[1]) == "--pub") {
            publish(participant, topic);
        } else {
            subscribe(participant, topic);
        }
        if (stop_requested) {
            std::cout << "Stopped." << std::endl;
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << std::endl;
        return 1;
    }
}
