const long WireloomBuildBound = 24;
// No longer included.

