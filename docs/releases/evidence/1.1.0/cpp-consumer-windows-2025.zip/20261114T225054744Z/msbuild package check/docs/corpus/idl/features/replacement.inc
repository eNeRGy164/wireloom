const long WireloomBuildBound = 32;
