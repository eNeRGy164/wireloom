file(REMOVE_RECURSE
  "CMakeFiles/verify"
  "wireloom/contract/01-primitives.cxx"
  "wireloom/contract/01-primitives.hpp"
  "wireloom/contract/01-primitivesPlugin.cxx"
  "wireloom/contract/01-primitivesPlugin.hpp"
  "wireloom/contract/generation.stamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/verify.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
