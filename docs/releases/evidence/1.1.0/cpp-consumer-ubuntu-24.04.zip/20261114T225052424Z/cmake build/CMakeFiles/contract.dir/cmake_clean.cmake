file(REMOVE_RECURSE
  "CMakeFiles/contract.dir/wireloom/contract/01-primitives.cxx.o"
  "CMakeFiles/contract.dir/wireloom/contract/01-primitives.cxx.o.d"
  "CMakeFiles/contract.dir/wireloom/contract/01-primitivesPlugin.cxx.o"
  "CMakeFiles/contract.dir/wireloom/contract/01-primitivesPlugin.cxx.o.d"
  "wireloom/contract/01-primitives.cxx"
  "wireloom/contract/01-primitives.hpp"
  "wireloom/contract/01-primitivesPlugin.cxx"
  "wireloom/contract/01-primitivesPlugin.hpp"
  "wireloom/contract/generation.stamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/contract.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
